<!-- social Section Starts Here -->
<section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="#"><img src=""/></a>
                </li>
                <li>
                    <a href="#"><img src=""/></a>
                </li>
                <li>
                    <a href="#"><img src=""/></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p> Blood Bank All rights reserved.</p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>