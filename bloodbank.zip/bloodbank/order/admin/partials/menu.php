<?php 

    include('../../file/connection.php'); 
    

?>


<html>
    <head>
        <title>Online Blood Order</title>

        <link rel="stylesheet" href="../css/admin.css">
    </head>
    
    <body>
        <!-- Menu Section Starts -->
        <div class="menu text-center">
            <div class="wrapper">
                <ul>
                <li>
                        <a href="<?php echo SITEURL; ?>">Home</a>
                    </li>
                    <li><a href="manage-category.php">Category</a></li>
                    <li><a href="manage-food.php">Blood Sample</a></li>
                    <li><a href="manage-order.php">Order Section</a></li>
                   
                   
                </ul>
            </div>
        </div>
        <!-- Menu Section Ends -->