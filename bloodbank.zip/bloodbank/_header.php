<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?= $title; ?></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css/dcss/bootstrap.min.css">
        <link rel="stylesheet" href="../css/dcss/mystyle.css">
        <script src="../css/dcss/jquery.min.js"></script>
        <script src="../css/dcss/bootstrap.min.js"></script>
        <script src="../css/dcss/myjs.js"></script>
    </head>
    <body>


